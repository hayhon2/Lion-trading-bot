
# Lion Trading Bot

بوت تلغرام جاهز للتعديل والعمل.

## طريقة التشغيل
1. ضع توكن البوت في المتغير BOT_TOKEN.
2. ثبّت المتطلبات:
   ```
   pip install -r requirements.txt
   ```
3. شغل البوت:
   ```
   python3 main.py
   ```
